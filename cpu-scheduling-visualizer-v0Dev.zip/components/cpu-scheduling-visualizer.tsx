"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Cpu,
  Plus,
  Play,
  RotateCcw,
  Clock,
  Layers,
  Trash2,
  ChevronDown,
} from "lucide-react";

interface Process {
  id: string;
  name: string;
  arrivalTime: number;
  burstTime: number;
  remainingTime: number;
  color: string;
}

interface GanttBlock {
  processId: string;
  processName: string;
  startTime: number;
  endTime: number;
  color: string;
}

interface SchedulingResult {
  waitingTime: number;
  turnaroundTime: number;
  completionTime: number;
}

const PROCESS_COLORS = [
  "oklch(0.7 0.18 200)",
  "oklch(0.65 0.2 170)",
  "oklch(0.75 0.15 60)",
  "oklch(0.6 0.22 25)",
  "oklch(0.65 0.18 300)",
  "oklch(0.7 0.15 140)",
  "oklch(0.68 0.2 30)",
  "oklch(0.72 0.16 250)",
];

export default function CPUSchedulingVisualizer() {
  const [processes, setProcesses] = useState<Process[]>([
    {
      id: "P1",
      name: "P1",
      arrivalTime: 0,
      burstTime: 5,
      remainingTime: 5,
      color: PROCESS_COLORS[0],
    },
    {
      id: "P2",
      name: "P2",
      arrivalTime: 1,
      burstTime: 3,
      remainingTime: 3,
      color: PROCESS_COLORS[1],
    },
    {
      id: "P3",
      name: "P3",
      arrivalTime: 2,
      burstTime: 8,
      remainingTime: 8,
      color: PROCESS_COLORS[2],
    },
  ]);

  const [algorithm, setAlgorithm] = useState<"FCFS" | "RR">("FCFS");
  const [timeQuantum, setTimeQuantum] = useState(2);
  const [isRunning, setIsRunning] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [readyQueue, setReadyQueue] = useState<Process[]>([]);
  const [executingProcess, setExecutingProcess] = useState<Process | null>(
    null
  );
  const [ganttChart, setGanttChart] = useState<GanttBlock[]>([]);
  const [results, setResults] = useState<Map<string, SchedulingResult>>(
    new Map()
  );
  const [isAlgorithmOpen, setIsAlgorithmOpen] = useState(false);
  const simulationRef = useRef<NodeJS.Timeout | null>(null);

  const resetSimulation = useCallback(() => {
    setIsRunning(false);
    setCurrentTime(0);
    setReadyQueue([]);
    setExecutingProcess(null);
    setGanttChart([]);
    setResults(new Map());
    setProcesses((prev) =>
      prev.map((p) => ({ ...p, remainingTime: p.burstTime }))
    );
    if (simulationRef.current) {
      clearTimeout(simulationRef.current);
    }
  }, []);

  const addProcess = () => {
    const newId = `P${processes.length + 1}`;
    const newProcess: Process = {
      id: newId,
      name: newId,
      arrivalTime: 0,
      burstTime: 4,
      remainingTime: 4,
      color: PROCESS_COLORS[processes.length % PROCESS_COLORS.length],
    };
    setProcesses([...processes, newProcess]);
  };

  const removeProcess = (id: string) => {
    setProcesses(processes.filter((p) => p.id !== id));
  };

  const updateProcess = (
    id: string,
    field: keyof Process,
    value: number | string
  ) => {
    setProcesses(
      processes.map((p) => {
        if (p.id === id) {
          const updated = { ...p, [field]: value };
          if (field === "burstTime") {
            updated.remainingTime = value as number;
          }
          return updated;
        }
        return p;
      })
    );
  };

  const runSimulation = useCallback(() => {
    if (isRunning) return;

    resetSimulation();
    setIsRunning(true);

    const processQueue = processes.map((p) => ({
      ...p,
      remainingTime: p.burstTime,
    }));
    const completed: Map<string, SchedulingResult> = new Map();
    const gantt: GanttBlock[] = [];
    let time = 0;
    let ready: Process[] = [];
    let current: Process | null = null;
    let quantumRemaining = timeQuantum;

    const simulateStep = () => {
      // Add arriving processes to ready queue
      const arriving = processQueue.filter(
        (p) =>
          p.arrivalTime === time &&
          p.remainingTime > 0 &&
          !ready.find((r) => r.id === p.id) &&
          (!current || current.id !== p.id)
      );
      ready = [...ready, ...arriving];

      // FCFS Logic
      if (algorithm === "FCFS") {
        if (!current && ready.length > 0) {
          current = ready.shift()!;
        }

        if (current) {
          current.remainingTime--;

          if (
            gantt.length === 0 ||
            gantt[gantt.length - 1].processId !== current.id
          ) {
            gantt.push({
              processId: current.id,
              processName: current.name,
              startTime: time,
              endTime: time + 1,
              color: current.color,
            });
          } else {
            gantt[gantt.length - 1].endTime = time + 1;
          }

          if (current.remainingTime === 0) {
            const completionTime = time + 1;
            const turnaroundTime = completionTime - current.arrivalTime;
            const waitingTime = turnaroundTime - current.burstTime;
            completed.set(current.id, {
              waitingTime,
              turnaroundTime,
              completionTime,
            });
            current = null;
          }
        }
      }

      // Round Robin Logic
      if (algorithm === "RR") {
        if (!current && ready.length > 0) {
          current = ready.shift()!;
          quantumRemaining = timeQuantum;
        }

        if (current) {
          current.remainingTime--;
          quantumRemaining--;

          if (
            gantt.length === 0 ||
            gantt[gantt.length - 1].processId !== current.id
          ) {
            gantt.push({
              processId: current.id,
              processName: current.name,
              startTime: time,
              endTime: time + 1,
              color: current.color,
            });
          } else {
            gantt[gantt.length - 1].endTime = time + 1;
          }

          if (current.remainingTime === 0) {
            const completionTime = time + 1;
            const turnaroundTime = completionTime - current.arrivalTime;
            const waitingTime =
              turnaroundTime -
              processQueue.find((p) => p.id === current!.id)!.burstTime;
            completed.set(current.id, {
              waitingTime,
              turnaroundTime,
              completionTime,
            });
            current = null;
          } else if (quantumRemaining === 0) {
            ready.push(current);
            current = null;
          }
        }
      }

      time++;
      setCurrentTime(time);
      setReadyQueue([...ready]);
      setExecutingProcess(current ? { ...current } : null);
      setGanttChart([...gantt]);
      setResults(new Map(completed));

      const allCompleted = processQueue.every((p) => completed.has(p.id));
      const hasWork =
        ready.length > 0 ||
        current !== null ||
        processQueue.some((p) => p.arrivalTime >= time && !completed.has(p.id));

      if (!allCompleted && (hasWork || time < 50)) {
        simulationRef.current = setTimeout(simulateStep, 600);
      } else {
        setIsRunning(false);
      }
    };

    simulateStep();
  }, [processes, algorithm, timeQuantum, isRunning, resetSimulation]);

  useEffect(() => {
    return () => {
      if (simulationRef.current) {
        clearTimeout(simulationRef.current);
      }
    };
  }, []);

  const avgWaitingTime =
    results.size > 0
      ? Array.from(results.values()).reduce((a, b) => a + b.waitingTime, 0) /
        results.size
      : 0;

  const avgTurnaroundTime =
    results.size > 0
      ? Array.from(results.values()).reduce((a, b) => a + b.turnaroundTime, 0) /
        results.size
      : 0;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <div className="flex items-center justify-center gap-3">
            <motion.div
              animate={{ rotate: isRunning ? 360 : 0 }}
              transition={{
                duration: 2,
                repeat: isRunning ? Infinity : 0,
                ease: "linear",
              }}
            >
              <Cpu className="w-10 h-10 text-primary glow-text-cyan" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground glow-text-cyan">
              CPU Scheduling Visualizer
            </h1>
          </div>
          <p className="text-muted-foreground text-sm md:text-base">
            Visualize FCFS and Round Robin scheduling algorithms in real-time
          </p>
        </motion.header>

        {/* Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-xl p-4 md:p-6 glow-cyan"
        >
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-end">
            {/* Algorithm Selector */}
            <div className="w-full md:w-auto space-y-2">
              <label className="text-sm text-muted-foreground flex items-center gap-2">
                <Layers className="w-4 h-4" />
                Algorithm
              </label>
              <div className="relative">
                <button
                  onClick={() => setIsAlgorithmOpen(!isAlgorithmOpen)}
                  className="w-full md:w-48 px-4 py-2.5 bg-secondary/50 border border-border rounded-lg text-foreground flex items-center justify-between hover:bg-secondary/70 transition-colors"
                >
                  <span>
                    {algorithm === "FCFS"
                      ? "First Come First Serve"
                      : "Round Robin"}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${isAlgorithmOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <AnimatePresence>
                  {isAlgorithmOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full mt-2 w-full bg-card border border-border rounded-lg overflow-hidden z-10 shadow-xl"
                    >
                      <button
                        onClick={() => {
                          setAlgorithm("FCFS");
                          setIsAlgorithmOpen(false);
                          resetSimulation();
                        }}
                        className={`w-full px-4 py-2.5 text-left hover:bg-secondary/50 transition-colors ${
                          algorithm === "FCFS"
                            ? "bg-primary/20 text-primary"
                            : "text-foreground"
                        }`}
                      >
                        First Come First Serve (FCFS)
                      </button>
                      <button
                        onClick={() => {
                          setAlgorithm("RR");
                          setIsAlgorithmOpen(false);
                          resetSimulation();
                        }}
                        className={`w-full px-4 py-2.5 text-left hover:bg-secondary/50 transition-colors ${
                          algorithm === "RR"
                            ? "bg-primary/20 text-primary"
                            : "text-foreground"
                        }`}
                      >
                        Round Robin (RR)
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Time Quantum (for RR) */}
            <AnimatePresence>
              {algorithm === "RR" && (
                <motion.div
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: "auto" }}
                  exit={{ opacity: 0, width: 0 }}
                  className="space-y-2"
                >
                  <label className="text-sm text-muted-foreground flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Time Quantum
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={timeQuantum}
                    onChange={(e) => {
                      setTimeQuantum(parseInt(e.target.value) || 1);
                      resetSimulation();
                    }}
                    className="w-24 px-4 py-2.5 bg-secondary/50 border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="flex gap-2 ml-auto">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={runSimulation}
                disabled={isRunning || processes.length === 0}
                className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition-colors glow-cyan"
              >
                <Play className="w-4 h-4" />
                Run
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={resetSimulation}
                className="px-6 py-2.5 bg-secondary text-secondary-foreground rounded-lg font-medium flex items-center gap-2 hover:bg-secondary/70 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </motion.button>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Process Input Table */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="glass rounded-xl p-4 md:p-6 glow-cyan"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">
                Process Table
              </h2>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={addProcess}
                disabled={isRunning}
                className="px-4 py-2 bg-primary/20 text-primary rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-primary/30 transition-colors disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                Add Process
              </motion.button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-muted-foreground border-b border-border">
                    <th className="pb-3 pr-4">Process</th>
                    <th className="pb-3 pr-4">Arrival</th>
                    <th className="pb-3 pr-4">Burst</th>
                    <th className="pb-3"></th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {processes.map((process, index) => (
                      <motion.tr
                        key={process.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.05 }}
                        className="border-b border-border/50"
                      >
                        <td className="py-3 pr-4">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: process.color }}
                            />
                            <span className="text-foreground font-medium">
                              {process.name}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 pr-4">
                          <input
                            type="number"
                            min="0"
                            value={process.arrivalTime}
                            onChange={(e) =>
                              updateProcess(
                                process.id,
                                "arrivalTime",
                                parseInt(e.target.value) || 0
                              )
                            }
                            disabled={isRunning}
                            className="w-16 px-2 py-1 bg-secondary/50 border border-border rounded text-foreground text-center focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
                          />
                        </td>
                        <td className="py-3 pr-4">
                          <input
                            type="number"
                            min="1"
                            value={process.burstTime}
                            onChange={(e) =>
                              updateProcess(
                                process.id,
                                "burstTime",
                                parseInt(e.target.value) || 1
                              )
                            }
                            disabled={isRunning}
                            className="w-16 px-2 py-1 bg-secondary/50 border border-border rounded text-foreground text-center focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
                          />
                        </td>
                        <td className="py-3">
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={() => removeProcess(process.id)}
                            disabled={isRunning || processes.length <= 1}
                            className="p-1.5 text-muted-foreground hover:text-destructive transition-colors disabled:opacity-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </motion.button>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>

          {/* Ready Queue & CPU */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Ready Queue */}
            <div className="glass rounded-xl p-4 md:p-6 glow-teal">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-foreground">
                  Ready Queue
                </h2>
                <span className="text-sm text-muted-foreground">
                  Time: {currentTime}
                </span>
              </div>
              <div className="flex gap-2 min-h-[60px] items-center flex-wrap">
                <AnimatePresence mode="popLayout">
                  {readyQueue.length > 0 ? (
                    readyQueue.map((process, index) => (
                      <motion.div
                        key={`${process.id}-${index}`}
                        initial={{ opacity: 0, scale: 0.5, x: 50 }}
                        animate={{ opacity: 1, scale: 1, x: 0 }}
                        exit={{ opacity: 0, scale: 0.5, x: -50 }}
                        className="px-4 py-2 rounded-lg border-2 font-medium"
                        style={{
                          backgroundColor: `color-mix(in oklch, ${process.color} 20%, transparent)`,
                          borderColor: process.color,
                          color: process.color,
                        }}
                      >
                        {process.name}
                      </motion.div>
                    ))
                  ) : (
                    <span className="text-muted-foreground text-sm">
                      Queue is empty
                    </span>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* CPU Execution */}
            <div className="glass rounded-xl p-4 md:p-6 glow-cyan">
              <h2 className="text-lg font-semibold text-foreground mb-4">
                CPU Execution
              </h2>
              <div className="relative flex items-center justify-center min-h-[120px]">
                <motion.div
                  className={`w-32 h-32 rounded-2xl border-2 border-primary flex items-center justify-center ${
                    executingProcess ? "animate-pulse-glow" : ""
                  }`}
                  style={{
                    backgroundColor: executingProcess
                      ? `color-mix(in oklch, ${executingProcess.color} 30%, transparent)`
                      : "transparent",
                    borderColor: executingProcess
                      ? executingProcess.color
                      : "var(--border)",
                  }}
                >
                  <AnimatePresence mode="wait">
                    {executingProcess ? (
                      <motion.div
                        key={executingProcess.id}
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.5 }}
                        className="text-center"
                      >
                        <Cpu
                          className="w-8 h-8 mx-auto mb-2"
                          style={{ color: executingProcess.color }}
                        />
                        <p
                          className="text-xl font-bold"
                          style={{ color: executingProcess.color }}
                        >
                          {executingProcess.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Remaining: {executingProcess.remainingTime}
                        </p>
                      </motion.div>
                    ) : (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center text-muted-foreground"
                      >
                        <Cpu className="w-8 h-8 mx-auto mb-2 opacity-30" />
                        <p className="text-sm">Idle</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Gantt Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-xl p-4 md:p-6 glow-cyan"
        >
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Gantt Chart
          </h2>
          <div className="overflow-x-auto pb-4">
            <div className="flex gap-0 min-h-[80px] items-end">
              <AnimatePresence>
                {ganttChart.length > 0 ? (
                  ganttChart.map((block, index) => (
                    <motion.div
                      key={`${block.processId}-${block.startTime}`}
                      initial={{ opacity: 0, scaleX: 0 }}
                      animate={{ opacity: 1, scaleX: 1 }}
                      className="relative flex flex-col items-center"
                      style={{ originX: 0 }}
                    >
                      <motion.div
                        className="h-14 flex items-center justify-center px-2 min-w-[40px] border-r border-background/50 font-medium text-sm"
                        style={{
                          backgroundColor: block.color,
                          width: `${(block.endTime - block.startTime) * 40}px`,
                          color: "oklch(0.08 0.02 260)",
                        }}
                        whileHover={{ scale: 1.05, zIndex: 10 }}
                      >
                        {block.processName}
                      </motion.div>
                      <div className="flex justify-between w-full text-xs text-muted-foreground mt-1">
                        <span>{block.startTime}</span>
                        {index === ganttChart.length - 1 && (
                          <span>{block.endTime}</span>
                        )}
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="flex items-center justify-center w-full h-[80px] text-muted-foreground text-sm">
                    Run simulation to see Gantt chart
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>

        {/* Results Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-xl p-4 md:p-6 glow-teal"
        >
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Performance Metrics
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-sm text-muted-foreground border-b border-border">
                  <th className="pb-3 pr-4">Process</th>
                  <th className="pb-3 pr-4">Arrival Time</th>
                  <th className="pb-3 pr-4">Burst Time</th>
                  <th className="pb-3 pr-4">Completion Time</th>
                  <th className="pb-3 pr-4">Turnaround Time</th>
                  <th className="pb-3">Waiting Time</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence>
                  {processes.map((process, index) => {
                    const result = results.get(process.id);
                    return (
                      <motion.tr
                        key={process.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className="border-b border-border/50"
                      >
                        <td className="py-3 pr-4">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: process.color }}
                            />
                            <span className="text-foreground font-medium">
                              {process.name}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">
                          {process.arrivalTime}
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">
                          {process.burstTime}
                        </td>
                        <td className="py-3 pr-4">
                          {result ? (
                            <motion.span
                              initial={{ opacity: 0, scale: 0.5 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="text-primary font-medium"
                            >
                              {result.completionTime}
                            </motion.span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="py-3 pr-4">
                          {result ? (
                            <motion.span
                              initial={{ opacity: 0, scale: 0.5 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="text-accent font-medium"
                            >
                              {result.turnaroundTime}
                            </motion.span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="py-3">
                          {result ? (
                            <motion.span
                              initial={{ opacity: 0, scale: 0.5 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="text-chart-3 font-medium"
                            >
                              {result.waitingTime}
                            </motion.span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </td>
                      </motion.tr>
                    );
                  })}
                </AnimatePresence>
              </tbody>
              {results.size > 0 && (
                <tfoot>
                  <tr className="border-t border-border">
                    <td
                      colSpan={4}
                      className="pt-3 text-right font-semibold text-foreground"
                    >
                      Averages:
                    </td>
                    <td className="pt-3 pr-4">
                      <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-accent font-bold"
                      >
                        {avgTurnaroundTime.toFixed(2)}
                      </motion.span>
                    </td>
                    <td className="pt-3">
                      <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-chart-3 font-bold"
                      >
                        {avgWaitingTime.toFixed(2)}
                      </motion.span>
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
